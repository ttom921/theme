# MgMonokai #

## Schemes & Editors

* MgMonokai.ksf	-> KomodoEdit & KomodoIde

## Contact ##

* <http://twitter.com/olouv>
* [contact@mg-crea.com](mailto:contact@mg-crea.com)
* <http://mg-crea.com>

## License ##

* Copyright (c) 2010 [Magenta Creations](http://mg-crea.com). All rights reserved.
* Licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 3.0 License.
*  Summary : <http://creativecommons.org/licenses/by-nc-sa/3.0/>
*  Legal : <http://creativecommons.org/licenses/by-nc-sa/3.0/legalcode>