# Monokai theme for Visual Studio 2015
Fork of https://github.com/mmonteleone/monokai-vs but with changes for Visual Studio 2015

#Features
* As close as possible to Monokai
* C#, XAML, XML, CSS, JS, HTML and CSHTML (also ASP.NET 5)

#Usage
Tools > Import and Export Settings > Select "Import selected environment settings" > Save current settings or just replace > Browse to the monokai_15.vssettings file downloaded/cloned from here >  Finish
